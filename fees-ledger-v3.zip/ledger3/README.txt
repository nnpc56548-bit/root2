SCHOOL FEES LEDGER, version 3 (HTML + CSS + JavaScript, separate files)

UPDATING YOUR GITHUB SITE
  Upload everything in this folder to your repository, replacing the old files.
  IMPORTANT: if you already changed the admin password, do NOT replace js/config.js.
  (Starting admin password in the included config.js: snKpNeVgsW. Change it with hash.html.)
  Your saved records are in the browser, not in these files, so updating does not erase them.
  Bursar accounts are created by the admin in Settings > Bursars (up to 11).

PAGES
  index.html  login        home.html  welcome + "My activity"     students.html  by class, Add student +
  payments.html  record/edit/void, overpayment prompt            receipts.html  who, when, method, by whom
  photos.html  upload many photos and assign to students         reports.html   graphs, unpaid list, per-bursar totals
  notifications.html  alerts with red dot                         settings.html  appearance, school, currency, fees,
                                                                                 term, bursars, demo data, backup
  hash.html  makes the fingerprint for a new ADMIN password

GOOD TO KNOW
  - Records autosave in the browser on this device. Download a backup regularly (Settings).
  - Currency conversion changes all amounts once. A backup downloads first.
  - Demo students (Settings > Demo data) are marked "demo" and can be removed together.
  - Passwords are a lock for the device, not bank-level security.
